/* fichier source.h */
#define SC_INCLUDE_FX
#ifndef SOURCE_H
#define SOURCE_H

#include <cstddef>     // 专门解决 ptrdiff_t 报错！
#include <vector>      // 专门解决 max_size 报错！
#include <string>      // 专门解决 basic_string 报错！
#include <systemc.h>

typedef sc_fixed<23, 18, SC_RND, SC_SAT> data_t;

SC_MODULE(SOURCE)
    {
        sc_in_clk    clk;
        //sc_fifo_out<float> out;
        sc_out<data_t> out_real;
        sc_out<data_t> out_imag;
        sc_out<bool>  out_valid;
        sc_in<bool>   in_req;

        void COMPORTEMENT();

          SC_CTOR(SOURCE)
                {
                  SC_THREAD(COMPORTEMENT);
                  sensitive << clk.pos();
                 }
};
#endif
