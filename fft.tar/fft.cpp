/* fichier fft.cpp */

#include <iostream>
#include "fft.h"
using std::cout;
using std::endl;

void butterfly(data_t &ar, data_t &ai, data_t &br, data_t &bi, data_t wr, data_t wi)
{
    data_t tr = br * wr - bi * wi;
    data_t ti = br * wi + bi * wr;

    br = ar - tr;
    bi = ai - ti;

    ar = ar + tr;
    ai = ai + ti;
}

const data_t W_R[4] = {1, 0.7071067812, 0, -0.7071067812};
const data_t W_I[4] = {0, -0.7071067812, -1, -0.7071067812};

// your code
void FFT::process()
{
    int i = 0;
    int k = 0;
    int k1 = 0;
    int j = 0;
    float R[8], I[8];           // conserver les donnée (Real, Imag)
    float temp_R[8], temp_I[8]; // temporaire pour les calculs
    out_req.write(true);
    //out_valid_sink.write(true);

    while (1)
    {
        wait();
        cout << "[FFT: " << sc_time_stamp() << "] i= " << i << endl;
        // 1. lire
        // out_req.write(true);
        if (i < 8 && j == 0)
        {
            if (in_valid.read() == true && out_req)
            {
                temp_R[i] = in_real.read();
                temp_I[i] = in_imag.read();
                i++;
            }
        }

        if (i == 8)
            out_req.write(false);
        else
            out_req.write(true);

        // out_req.write(false);
        
        if (i == 8 && k == 0)
        {
            for (k1 = 0; k1 < 8; k1++)
            {
                cout << "real = " << temp_R[k1] << "   imag = " << temp_I[k1] << endl;
            }
            // 2. calcule
            R[0] = temp_R[0];
            I[0] = temp_I[0];
            R[1] = temp_R[4];
            I[1] = temp_I[4];
            R[2] = temp_R[2];
            I[2] = temp_I[2];
            R[3] = temp_R[6];
            I[3] = temp_I[6];
            R[4] = temp_R[1];
            I[4] = temp_I[1];
            R[5] = temp_R[5];
            I[5] = temp_I[5];
            R[6] = temp_R[3];
            I[6] = temp_I[3];
            R[7] = temp_R[7];
            I[7] = temp_I[7];
            // === STAGE 1 (premier colonne) ===
            butterfly(R[0], I[0], R[1], I[1], W_R[0], W_I[0]);
            butterfly(R[2], I[2], R[3], I[3], W_R[0], W_I[0]);
            butterfly(R[4], I[4], R[5], I[5], W_R[0], W_I[0]);
            butterfly(R[6], I[6], R[7], I[7], W_R[0], W_I[0]);

            // === STAGE 2 (second colonne) ===
            butterfly(R[0], I[0], R[2], I[2], W_R[0], W_I[0]); // Group 1
            butterfly(R[1], I[1], R[3], I[3], W_R[2], W_I[2]); // Group 1 (W2)

            butterfly(R[4], I[4], R[6], I[6], W_R[0], W_I[0]); // Group 2
            butterfly(R[5], I[5], R[7], I[7], W_R[2], W_I[2]); // Group 2 (W2)

            // === STAGE 3 (troisième colonne) ===
            // W0, W1, W2, W3
            butterfly(R[0], I[0], R[4], I[4], W_R[0], W_I[0]);
            butterfly(R[1], I[1], R[5], I[5], W_R[1], W_I[1]);
            butterfly(R[2], I[2], R[6], I[6], W_R[2], W_I[2]);
            butterfly(R[3], I[3], R[7], I[7], W_R[3], W_I[3]);

            for (k = 0; k < 8; k++)
            {
                cout << "real = " << R[k] << "   imag = " << I[k] << " k = "<< k << endl;
            }
        }

                // 3. écrir
        //out_valid_sink.write(true);
        if (k == 8)
        {   
            if (j == 0){
            out_valid_sink.write(true);
            out_real_sink.write(R[j]);
            out_imag_sink.write(I[j]);
            }

            if (j < 8)
            {
                 if (in_req_sink.read() == true && out_valid_sink)
                {
                    cout << "real = " << R[j+1] << "   imag = " << I[j+1] << " j = "<< j << endl;
                    out_real_sink.write(R[j+1]);
                    out_imag_sink.write(I[j+1]);
                    j++;
                }
            }

            if (j == 8){
                out_valid_sink.write(false);
                j = 0;
                i = 0;
                k = 0;
            }else{
                out_valid_sink.write(true);
            }
        }
    }
}
