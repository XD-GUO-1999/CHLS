
#ifndef FFT_H
#define FFT_H

#define SC_INCLUDE_FX
#include <systemc.h>

typedef sc_fixed<23, 18, SC_RND, SC_SAT> data_t;

SC_MODULE(FFT)
    {
        sc_in_clk clk;
        // sc_fifo_in<float> in;       
        //sc_fifo_out<float> out;

        sc_in<data_t> in_real;
        sc_in<data_t> in_imag;
        sc_in<bool>  in_valid;
        sc_out<bool> out_req;

        sc_out<data_t> out_real_sink;
        sc_out<data_t> out_imag_sink;
        sc_out<bool>  out_valid_sink;
        sc_in<bool> in_req_sink;

        data_t sample_real[8];
        data_t sample_imag[8];

        SC_CTOR(FFT) {
            SC_THREAD(process);
            sensitive << clk.pos();
        }
        void process();
    };      
#endif

